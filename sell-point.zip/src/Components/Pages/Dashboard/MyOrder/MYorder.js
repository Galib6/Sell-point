import { useQuery } from '@tanstack/react-query';
import React, { useContext, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../../../../context/AuthProvider';
import Loading from '../../../Shared/Loading/Loading';
import Mysingorder from './mysingorder';

const MYorder = () => {
    const { user } = useContext(AuthContext)
    // const [myorders, setMyorders] = useState()
    const { data: myorders = [], refetch, isLoading } = useQuery({
        queryKey: ["myorders"],
        queryFn: async () => {

            const res = await fetch(`http://localhost:5000/myorders?email=${user?.email}`);
            const data = await res.json();
            console.log(data)
            return data;
        }
    })


    if (isLoading) {
        return <Loading></Loading>
    }


    return (
        <div>
            <h2 className='text-3xl mb-2'>All buyers</h2>
            <div className="overflow-x-auto">
                <table className="table w-full">

                    <thead>
                        <tr>
                            <th>Sl</th>
                            <th>Product Name</th>
                            <th>Meeting Location</th>
                            <th>Booking Date</th>
                            <th>Pay</th>

                        </tr>
                    </thead>
                    <tbody>

                        {
                            myorders?.map((myorder, i) =>
                                <Mysingorder
                                    key={myorder._Id}
                                    myorder={myorder}
                                    i={i}
                                ></Mysingorder>)
                        }

                    </tbody>
                </table>
            </div>
        </div>

    );
};

export default MYorder;