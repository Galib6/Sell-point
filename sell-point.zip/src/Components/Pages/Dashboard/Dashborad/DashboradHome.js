import React from 'react';

const DashboradHome = () => {
    return (
        <div className='min-h-screen flex flex-col justify-center items-center'>
            <h4 className='text-6xl font-bold flex justify-center items-center'>Dashborad</h4>
            <p>Press Side Manu Button to Explore</p>
            <p>Hope Your Experiencing Best</p>
        </div>
    );
};

export default DashboradHome;